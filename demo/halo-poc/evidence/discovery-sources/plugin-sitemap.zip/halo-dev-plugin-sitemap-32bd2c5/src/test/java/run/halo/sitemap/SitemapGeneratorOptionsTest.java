package run.halo.sitemap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.net.MalformedURLException;
import java.net.URL;
import org.junit.jupiter.api.Test;

/**
 * Tests for {@link SitemapGeneratorOptions}.
 *
 * @author guqing
 * @since 1.0.0
 */
class SitemapGeneratorOptionsTest {

    @Test
    void transform() throws MalformedURLException {
        SitemapGeneratorOptions options = SitemapGeneratorOptions.builder()
            .siteUrl(new URL("https://halo.run"))
            .build();

        SitemapEntry entry = options.transform(new UrlEntryMeta("/about"));
        assertEquals("https://halo.run/about", entry.getLoc());
        assertNull(entry.getLastmod());

        entry = options.transform(new UrlEntryMeta("/archives"));
        assertEquals("https://halo.run/archives", entry.getLoc());
        assertNull(entry.getLastmod());

        entry = options.transform(new UrlEntryMeta("/categories/ümlat/>&>中"));
        assertEquals("https://halo.run/categories/%C3%BCmlat/&gt;&amp;&gt;%E4%B8%AD",
            entry.getLoc());
        assertNull(entry.getLastmod());

        entry = options.transform(new UrlEntryMeta("https://guqing.xyz/hello-中国<>&"));
        assertEquals("https://guqing.xyz/hello-%E4%B8%AD%E5%9B%BD&lt;&gt;&amp;",
            entry.getLoc());
        assertNull(entry.getLastmod());
    }
}
